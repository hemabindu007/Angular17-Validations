export class User {
    name!: string;
    email!: string;
    mobile!: Number;
    role!: string;
    designation!: string;
    blood_group!: string;
    date_of_joining!: number;
    address!: string;
    mail_address!: string;
    password!: string;
    gender!: string;
    token!: string;
    userId!: string;
    full_name!:string;
  }
  