import { Component, OnInit } from '@angular/core';
import { ChartType, ChartOptions } from 'chart.js';
import { SingleDataSet, Label, Color, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { DashboardService } from 'src/app/services/dashboard.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import * as moment from 'moment';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { EmployeeService } from 'src/app/services/employee.service';
import * as pluginDataLabels from 'chartjs-plugin-datalabels';

@Component({
  selector: 'app-dashboard-new',
  templateUrl: './dashboard-new.component.html',
  styleUrls: ['./dashboard-new.component.scss']
})
export class DashboardNewComponent implements OnInit {

  dashData
  piechartdata: number[] = []
  greetsLatest: any = [];
  canceledGreets: any = []
  stationWiseGreetsCount: any = []
  stations = []
  startDate;
  endDate;
  searchText;
  filterSelection = 'Current month'

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    plugins: {
      datalabels: {
        // display:false,
        color: '#ffffff',
        formatter: (value, ctx) => {
          const label = ctx.chart.data[ctx.dataIndex];
          return label;
        },
        font: {
          weight: 'bold',
          size: 12,
        },
        display: function (context) {
          return context.dataset.data[context.dataIndex] !== 0; // or >= 1 or ...
        }
      },
    }
  };
  public barChartLabels = [];
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [];
  public barChartColors: Color[] = [
    { backgroundColor: '#4c86a0' },
    { backgroundColor: '#30445c' },
    { backgroundColor: '#a7c2cf' },
  ]
  public barChartPlugins = [pluginDataLabels];
  constructor(private dashboardService: DashboardService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private empService: EmployeeService,
    private authService: AuthenticationService) {
    monkeyPatchChartJsTooltip();
    monkeyPatchChartJsLegend();
  }

  ngOnInit() {
    this.startDate = moment().startOf('month').startOf('day').format('MM/DD/YYYY HH:mm');
    this.endDate = moment().endOf('month').endOf('day').format('MM/DD/YYYY HH:mm');
    this.getData()
  }

  getData() {
    this.spinner.show()
    if (this.authService.isStationAdmin()) {
      this.empService.getEmployeeById(this.authService.getCurrentUserId()).subscribe(async res => {
        res['result']['stations'].forEach(station => {
          this.stations.push(station.stationid);
        });
        await this.getDashboardData()
        await this.getDashBoardGreets()
        await this.getCanceledGreets()
        await this.getStationWiseGreets();
      })
      this.spinner.hide()
    } else {
      this.getDashboardData()
      this.getDashBoardGreets()
      this.getCanceledGreets()
      this.getStationWiseGreets();
      this.spinner.hide();
    }
  }

  async getDashboardData() {
    this.pieChartData.length = 0
    await this.dashboardService.getDashboardData(this.stations, this.startDate, this.endDate).subscribe(res => {
      if (res['status']) {
        this.dashData = res['result']
        this.piechartdata.push(this.dashData.unssigned)
        this.piechartdata.push(this.dashData.assigned)
        this.piechartdata.push(this.dashData.inProgress)
        this.piechartdata.push(this.dashData.completed)
        this.piechartdata.push(this.dashData.cancelled)
        console.log(this.piechartdata);
      }
    })
  }

  getDashBoardGreets() {
    this.dashboardService.getDashboardGreets(this.stations).subscribe(res => {
      this.greetsLatest = res['result'];
    })
  }

  getCanceledGreets() {
    this.dashboardService.getCanceledGreets(this.stations).subscribe((res: any) => {
      this.canceledGreets = (res.result);
      this.spinner.hide();
    }, err => {
    })
  }


  // groupBy(list, keyGetter) {
  //   const map = new Map();
  //   list.forEach((item) => {
  //     const key = keyGetter(item);
  //     const collection = map.get(key);
  //     if (!collection) {
  //       map.set(key, [item]);
  //     } else {
  //       collection.push(item);
  //     }
  //   });
  //   return map;
  // }


  // example usage

  // const pets = [
  //     {type:"Dog", name:"Spot"},
  //     {type:"Cat", name:"Tiger"},
  //     {type:"Dog", name:"Rover"}, 
  //     {type:"Cat", name:"Leo"}
  // ];

  groupBy = keys => array =>
    array.reduce((objectsByKeyValue, obj) => {
      const value = keys.map(key => obj[key]).join('-');
      objectsByKeyValue[value] = (objectsByKeyValue[value] || []).concat(obj);
      return objectsByKeyValue;
    }, {});

  getStationWiseGreets() {
   // console.log(this.stations);
    this.barChartData = [];
    this.barChartLabels = [];
    let reqBody = {
      "date": this.startDate,
      "stationId": this.stations,
      "endDate": this.endDate
    }
    this.dashboardService.getStationWiseGreets(reqBody).subscribe((res: any) => {
      this.stationWiseGreetsCount = (res.result);
      if (this.stationWiseGreetsCount) {

        let completedData = [];
        let pendingData = [];
        let cancelData = [];



        const groupByStation = this.groupBy(['AirportIATA']);

        for (let [groupName, values] of Object.entries(groupByStation(this.stationWiseGreetsCount))) {
          // console.log("--PENDING--");
        //  console.log(groupName);
          let eachStationData = [];
          eachStationData.push(values);
          this.barChartLabels.push(groupName);
          //Pending...
          var pendingDataFilter = eachStationData[0].filter(value => value.ResStatusID === "Pending");
        //  console.log(pendingDataFilter.length);
          if (pendingDataFilter.length > 0) {
            pendingData.push(pendingDataFilter[0].Count);
          } else {
            pendingData.push(0);
          }

          //Cancelled...
          var cancelDataFilter = eachStationData[0].filter(value => value.ResStatusID === "Cancelled");
         // console.log(cancelDataFilter.length);
          if (cancelDataFilter.length > 0) {
            cancelData.push(cancelDataFilter[0].Count);
          } else {
            cancelData.push(0);
          }

          //Completed....
          var completedDataFilter = eachStationData[0].filter(value => value.ResStatusID === "Completed");
        //  console.log(completedDataFilter.length);
          if (completedDataFilter.length > 0) {
            completedData.push(completedDataFilter[0].Count);
          } else {
            completedData.push(0);
          }
        }

       // console.log(pendingData);
      //  console.log(cancelData);
       // console.log(completedData);
        this.barChartData.push({ data: pendingData, label: 'Pending', stack: 'a' });
        this.barChartData.push({ data: cancelData, label: 'Cancelled', stack: 'a' });
        this.barChartData.push({ data: completedData, label: 'Completed', stack: 'a' });
      }
      this.spinner.hide();
    }, err => {
    })
  }


  reservationDetails() {
    let cancelTabId: any = 2;
    localStorage.setItem('activeTab', cancelTabId);
    this.router.navigateByUrl('/home/greets')
  }

  reservationAssignedDetails() {
    let assignTab: any = 1;
    localStorage.setItem('activeTab', assignTab);
    this.router.navigateByUrl('/home/greets')
  }

  bookingsRoute() {
    let cancelTabId: any = 1;
    this.router.navigateByUrl('/home/bookings')
  }

  public pieChartOptions: ChartOptions = {
    responsive: true,
    legend: {
      position: 'right',
      labels: {
        fontSize: 12,
      }
    },
    plugins: {

      datalabels: {
        color: '#ffffff',
        formatter: (value, ctx) => {
          const label = ctx.chart.data[ctx.dataIndex];
          return label;
        },
        font: {
          weight: 'bold',
          size: 12,
        }
      },
    }
  };

  public pieChartLabels: Label[] = [['Unassigned'], ['Assigned'], ['InProgress'], ['Completed'], ['Cancelled']];
  public pieChartData: SingleDataSet = this.piechartdata
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [pluginDataLabels];
  public pieChartColors: Array<any> = [{
    backgroundColor: ['#011e41', '#4c86a0', '#848f9f', '#a7c2cf', '#30445c'],
    borderColor: ['#fff', '#fff', '#fff', '#fff', '#fff']
  }];
  //  011e41
  // 4c86a0
  // 848f9f
  // a7c2cf
  // 30445c

  currentMonth() {
    this.filterSelection = 'Current Month'
    this.startDate = moment().startOf('month').startOf('day').format('MM/DD/YYYY HH:mm');
    this.endDate = moment().endOf('month').endOf('day').format('MM/DD/YYYY HH:mm');
    this.getData()
  }

  lastThreeMonths() {
    this.filterSelection = 'Last 3 months'
    this.startDate = moment().subtract(3, 'months').startOf('day').format('MM/DD/YYYY HH:mm');
    this.endDate = moment().endOf('day').format('MM/DD/YYYY HH:mm');
    this.getData()
  }

  lastSixMonths() {
    this.filterSelection = 'Last 6 months'
    this.startDate = moment().subtract(6, 'months').startOf('day').format('MM/DD/YYYY HH:mm');
    this.endDate = moment().endOf('day').format('MM/DD/YYYY HH:mm');
    this.getData()
  }

  getUTCDate(date) {
    return moment.utc(date).format('MMM DD, YYYY HH:mm');
  }

  getReservationCanceledDate(UTCDate) {
    return new Date(UTCDate);
  }
}
